#include "DFA.h"
#include <iostream>
#include <fstream>
#include "json.hpp"

using namespace std;

using json = nlohmann::json;

DFA::DFA(string p){
    path = p;
    ifstream input(path);
    input >> dfa;
}

DFA::DFA(DFA dfa1, DFA dfa2, bool doorsnede){
    path1 = dfa1.path;
    path2 = dfa2.path;
    d = doorsnede;
    product(string (path1), string (path2), d);
}

bool DFA::accepts(string numbers){
    ifstream input(path);
    input >> dfa;

    string cur_node;

    for (int i = 0; i < dfa["states"].size(); i++){
        if (dfa["states"][i]["starting"] == true)
            cur_node =dfa["states"][i]["name"];
    }

    for (int i = 0; i < numbers.size(); i++) {
        char num = numbers[i];
        for (int i = 0; i < dfa["transitions"].size(); i++){
            string numb = dfa["transitions"][i]["input"];
            numb.erase(remove( numb.begin(), numb.end(), '\"' ),numb.end());

            if (dfa["transitions"][i]["from"] == cur_node && numb[0] == num){
                cur_node = dfa["transitions"][i]["to"];
                break;
            }
        }
    }

    for (int i = 0; i < dfa["states"].size(); i++){
        if (dfa["states"][i]["name"] == cur_node)
            return dfa["states"][i]["accepting"];
    }
}

void DFA::print(){
    ifstream input(path);
    input >> dfa;
    cout << dfa.dump(4) << endl;
}

string DFA::vecToString(vector<string> vec){
    return "(" + vec[0] + "," + vec[1] + ")";
}

pair<bool, bool> DFA::check(vector<string> state){
    vector<bool> bools = {false, false, false, false};
    pair<bool, bool> pair;

    for(int i = 0; i < dfa1["states"].size(); i++){
        if(dfa1["states"][i]["name"] == state[0]){
            if(dfa1["states"][i]["starting"])
                bools[0] = true;

            if(dfa1["states"][i]["accepting"])
                bools[2] = true;
        }
    }

    for(int i = 0; i < dfa2["states"].size(); i++){
        if(dfa2["states"][i]["name"] == state[1]){
            if(dfa2["states"][i]["starting"])
                bools[1] = true;

            if(dfa1["states"][i]["accepting"])
                bools[3] = true;
        }
    }

    pair.first = bools[0] && bools[1];

    if(d){
        pair.second = bools[2] && bools[3];
    }
    else{
        pair.second = bools[2] || bools[3];
    }

    return pair;
}

void DFA::addStates(){
    pair<bool, bool> c;

    for(auto state : states){
        c = check(state);
        dfa["states"].push_back(
                {{"name", vecToString(state)},
                {"starting", c.first},
                {"accepting", c.second}});
    }
}

void DFA::addTransition(string from, string to, string input){
    dfa["transitions"].push_back(
            {{"from",  from},
             {"to",    to},
             {"input", input}});
}

void DFA::multiply(string from1, string to1, string from2, string to2, string input){
    string from = "{" + from1 + "," + from2 + "}";
    string to = "{" + to1 + "," + to2 + "}";
        addTransition(from, to, input);
        states.insert({from1,from2});
        states.insert({to1, to2});
}

string DFA::findStart(json d){
    for(int i = 0; i < d["states"].size(); i++){
        if(d["states"][i]["starting"])
            return d["states"][i]["name"];
    }
}

string DFA::stateLoop(json d, string state, string input){
    string lol;
    for(int i = 0; i < d["transitions"].size(); i++){
        if(d["transitions"][i]["from"] == state && d["transitions"][i]["input"] == input)
            return d["transitions"][i]["to"];
    }
}

void DFA::findTransition(vector<string> state){
    vector<vector<string>> new_states;

    if (states.find(state) != states.end())
        return;
    states.insert(state);

    for(auto alph : dfa["alphabet"]){
        vector<string> new_state;

        new_state.push_back(stateLoop(dfa1, state[0], alph));
        new_state.push_back(stateLoop(dfa2, state[1], alph));

        addTransition(vecToString(state), vecToString(new_state), alph);
        new_states.push_back(new_state);
    }

    for(auto s : new_states){
        findTransition(s);
    }
}

void DFA::product(string d1, string d2, bool doorsnede){
    ifstream i1(d1);
    i1 >> dfa1;
    ifstream i2(d2);
    i2 >> dfa2;

    dfa = {
            {"type",     "DFA"},
            {"alphabet", dfa1["alphabet"]}
    };

    dfa["transitions"] = {"", ""};
    dfa["states"] = {"", ""};

    vector<string> start;
    start.push_back(findStart(dfa1));
    start.push_back(findStart(dfa2));

    findTransition(start);

    addStates();

    dfa["transitions"].erase(dfa["transitions"].begin());
    dfa["transitions"].erase(dfa["transitions"].begin());
    dfa["states"].erase(dfa["states"].begin());
    dfa["states"].erase(dfa["states"].begin());

    ofstream file("product.json");
    file << dfa;
    path = "product.json";
}