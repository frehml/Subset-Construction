//
// Created by Frederic Hamelink on 25/02/2021.
//

#include "NFA.h"
#include "json.hpp"
#include <fstream>
#include <array>

using namespace std;
using json = nlohmann::json;

NFA::NFA(string p){
    path = p;
    ifstream input(path);
    input >> nfa;
}

void NFA::findStates(string name){
    if(name == "")
        return;

    
}

DFA NFA::toDFA(){
    dfa = {
            {"type", "DFA"},
            {"alphabet", nfa["alphabet"]}
    };

    for (int i = 0; i < nfa["states"].size(); i++){
        if (nfa["states"][i]["starting"] == true){
            dfa["states"] = {"", (nfa["states"][i])};
        }
    }

    findStates(dfa["states"][1]["name"]);

    ofstream file("DFA.json");
    file << dfa;
    return DFA("DFA.json");
}